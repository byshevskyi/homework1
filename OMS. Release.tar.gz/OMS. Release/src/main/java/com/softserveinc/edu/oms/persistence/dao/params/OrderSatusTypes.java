//
// OrderSatusTypes
//
// 9 ���. 2011
//
package com.softserveinc.edu.oms.persistence.dao.params;

/**
 * @author Ivanka
 * 
 */
public class OrderSatusTypes {
	public static final String CREATED = "Created";
	public static final String PENDING = "Pending";
	public static final String ORDERED = "Ordered";
	public static final String DELIVERED = "Delivered";

}
