package com.softserveinc.edu.oms.web.user.util;

public class UserAvailability {
	private Boolean available;

	public UserAvailability() {
	}

	public Boolean isAvailable() {
		return available;
	}

	public void setAvailable(final Boolean available) {
		this.available = available;
	}
}
